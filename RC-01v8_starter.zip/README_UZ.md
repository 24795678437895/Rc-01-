# RC-01 v8 — Unity boshlang‘ich loyihasi

Bu arxiv RC-01 g‘oyasi asosida qayta yig‘ilgan **boshlang‘ich Unity loyiha skeleti**.
U tayyor, sinovdan o‘tgan APK emas. Samolyot modeli, teksturalar, tovushlar va Unity muharririda yakuniy sozlash hali kerak.

## Loyihada bor
- Android sensorli boshqaruv uchun samolyot boshqaruv skripti
- Tashqi va kabina kamerasi o‘rtasida almashish
- 360° radar HUD: o‘yin ichidagi nishonlarni 100 km gacha ko‘rsatish
- Android uchun oddiy UI matnlari

## Muhim
Radar masofasi o‘yin ichidagi sun’iy masofa. Bu haqiqiy F-35 AESA radari yoki real harbiy tizim emas.
100 km ko‘rsatkich ishlashi uchun nishonlar Unity sahnasida bo‘lishi va `RadarTarget` komponentiga ega bo‘lishi kerak.

## Unity’da o‘rnatish
1. Unity’da yangi 3D (Built-in Render Pipeline) loyiha yarating.
2. `Assets/RC01/Scripts` papkasini loyihaga ko‘chiring.
3. Sahna yarating va samolyot obyektiga `AircraftController` ni qo‘shing.
4. Samolyotga `CameraRig` va uning ichiga `ExternalCamera` hamda `CockpitCamera` kameralarini joylashtiring.
5. `RadarSystem` ni sahnadagi bo‘sh obyektga qo‘shing.
6. Nishon obyektlariga `RadarTarget` qo‘shing.
7. `RadarHUD` uchun Canvas va UI Text (Legacy) yarating, Inspector’da maydonlarni ulang.
8. Android Build Support o‘rnatilgan Unity muharririda Android platformasiga o‘ting.

## Boshqaruv
- Ekrandagi joystick/UI tugmalarini keyingi bosqichda ulash kerak.
- Hozircha skript klaviatura bilan ham sinash uchun o‘qishlarni qabul qiladi; Android touch UI alohida ulanadi.
