using UnityEngine;

public class RadarTarget : MonoBehaviour
{
    public string targetLabel = "TARGET";
}
