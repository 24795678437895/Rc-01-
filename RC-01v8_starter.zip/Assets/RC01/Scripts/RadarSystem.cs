using System.Collections.Generic;
using UnityEngine;

public class RadarSystem : MonoBehaviour
{
    [Min(1f)] public float rangeMeters = 100000f;
    [Range(1f, 360f)] public float scanAngle = 360f;
    [Min(0.05f)] public float scanInterval = 0.25f;
    public Transform aircraft;
    public List<RadarTarget> detectedTargets = new List<RadarTarget>();

    private float timer;

    void Update()
    {
        if (!aircraft) return;
        timer += Time.deltaTime;
        if (timer < scanInterval) return;
        timer = 0f;
        Scan();
    }

    void Scan()
    {
        detectedTargets.Clear();
        RadarTarget[] all = FindObjectsOfType<RadarTarget>();
        foreach (RadarTarget target in all)
        {
            if (!target || target.transform == aircraft) continue;
            Vector3 offset = target.transform.position - aircraft.position;
            if (offset.magnitude > rangeMeters) continue;

            float angle = Vector3.Angle(aircraft.forward, offset);
            if (angle <= scanAngle * 0.5f)
                detectedTargets.Add(target);
        }
    }
}
