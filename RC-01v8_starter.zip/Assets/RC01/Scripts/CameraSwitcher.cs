using UnityEngine;

public class CameraSwitcher : MonoBehaviour
{
    public Camera externalCamera;
    public Camera cockpitCamera;
    private bool cockpit;

    void Start() { SetView(false); }

    public void ToggleView() { SetView(!cockpit); }

    public void SetView(bool useCockpit)
    {
        cockpit = useCockpit;
        if (externalCamera) externalCamera.enabled = !cockpit;
        if (cockpitCamera) cockpitCamera.enabled = cockpit;
    }
}
