using UnityEngine;

// Connect UI sliders/buttons to these public methods in the Unity Inspector.
public class TouchInputBridge : MonoBehaviour
{
    public AircraftController aircraft;

    public void Pitch(float value) { if (aircraft) aircraft.SetPitch(value); }
    public void Roll(float value) { if (aircraft) aircraft.SetRoll(value); }
    public void Yaw(float value) { if (aircraft) aircraft.SetYaw(value); }
    public void Throttle(float value) { if (aircraft) aircraft.SetThrottle(value); }
}
