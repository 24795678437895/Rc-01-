using UnityEngine;
using UnityEngine.UI;
using System.Text;

public class RadarHUD : MonoBehaviour
{
    public RadarSystem radar;
    public Text statusText;

    void Update()
    {
        if (!statusText || !radar) return;
        StringBuilder output = new StringBuilder();
        output.AppendLine("RC-01 RADAR  |  360°");
        output.AppendLine("RANGE: " + (radar.rangeMeters / 1000f).ToString("F0") + " km");
        output.AppendLine("TARGETS: " + radar.detectedTargets.Count);
        foreach (RadarTarget target in radar.detectedTargets)
        {
            float km = Vector3.Distance(radar.aircraft.position, target.transform.position) / 1000f;
            output.AppendLine(target.targetLabel + "  " + km.ToString("F1") + " km");
        }
        statusText.text = output.ToString();
    }
}
