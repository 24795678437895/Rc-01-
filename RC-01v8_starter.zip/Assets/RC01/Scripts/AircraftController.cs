using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class AircraftController : MonoBehaviour
{
    [Header("Flight tuning")]
    public float thrust = 35f;
    public float pitchTorque = 18f;
    public float rollTorque = 22f;
    public float yawTorque = 8f;
    public float maxSpeed = 180f;

    [Header("Runtime input: connect Android UI buttons/sliders here")]
    [Range(-1f, 1f)] public float pitchInput;
    [Range(-1f, 1f)] public float rollInput;
    [Range(-1f, 1f)] public float yawInput;
    [Range(0f, 1f)] public float throttle = 0.65f;

    private Rigidbody body;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        body.useGravity = true;
        body.mass = 1200f;
        body.linearDamping = 0.15f;
        body.angularDamping = 1.5f;
    }

    void Update()
    {
        // Keyboard fallback for Editor testing.
        pitchInput = Mathf.Clamp(Input.GetAxis("Vertical"), -1f, 1f);
        rollInput = Mathf.Clamp(Input.GetAxis("Horizontal"), -1f, 1f);
        yawInput = 0f;
        if (Input.GetKey(KeyCode.Q)) yawInput = -1f;
        if (Input.GetKey(KeyCode.E)) yawInput = 1f;
        if (Input.GetKey(KeyCode.LeftShift)) throttle = Mathf.Min(1f, throttle + Time.deltaTime * 0.25f);
        if (Input.GetKey(KeyCode.LeftControl)) throttle = Mathf.Max(0f, throttle - Time.deltaTime * 0.25f);
    }

    void FixedUpdate()
    {
        body.AddForce(transform.forward * thrust * throttle, ForceMode.Acceleration);
        body.AddRelativeTorque(
            new Vector3(-pitchInput * pitchTorque, yawInput * yawTorque, -rollInput * rollTorque),
            ForceMode.Acceleration);

        if (body.velocity.magnitude > maxSpeed)
            body.velocity = body.velocity.normalized * maxSpeed;
    }

    // Call these from Android UI EventTrigger/Button/joystick callbacks.
    public void SetPitch(float value) { pitchInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetRoll(float value) { rollInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetYaw(float value) { yawInput = Mathf.Clamp(value, -1f, 1f); }
    public void SetThrottle(float value) { throttle = Mathf.Clamp01(value); }
}
